<h1> BadMod auto exploit tool </h1>
<br>
<h2>Version 2.0</h2>
<ul> 
<li>Fixed colors bug</li>
<li>Fixed permissions bug</li>
<li>Added new option to scan single target</li>
<li>Added new option to scan joomla & wordpress plugins</li>
</ul>
<br>
<h2>Installation</h2>
<ul> 
<li>Install tool</li>
<code>git clone https://github.com/MrSqar-Ye/BadMod.git</code>
<li>Install php</li>
<code>sudo apt-get install php</code>
<li>Install php curl</li>
<code>sudo apt-get install php-curl</code>
</ul>
<br>
<h2>Screen shots</h2>
<br>
<HR>
<h3>Header</h3><br>
<br>
<img src="ScreenShots/header.png" >
<br>
<HR>
<br>
<h3>Installation</h3><br>
<br>
<ul> 
<li>Install tool</li>
  <code>chmod +x INSTALL</code><br>
  <code>./INSTALL</code><br>
</ul>

<img src="ScreenShots/install.png" >
<br>
<h3>Option 1 - Get all server sites</h3><br>
<ul> 
<li>Fast tool to get all server sites .</li>
</ul>
<br>
<img src="ScreenShots/option1.png" >
<br>
<HR>
<h3>Option 2 - generate random IP's</h3><br>
<br>
<img src="ScreenShots/option2.png" >
<br>
<HR>

<h2>Video</h2><br>
<br>
<a href="https://youtu.be/5-BlWvzwMps" ><img src="ScreenShots/header.png" ></a>
<br>
<hr>
<h2>Report bug.</h2>
<ul>
  <li>Submit new issue <a href="https://github.com/M4DM0e/BadMod/issues">here</a></li>
</ul>
<br>
<h4>i Hope you like the tool, <3 :D :)</h4>
