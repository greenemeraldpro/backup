

# info-site

A simple script to collect information about websites and IP addresses:

the script by: KiNg-HaCkInG

![photo](https://c.top4top.net/p_921wll581.jpg)

*INSTALL:*
```
pkg install curl
pkg install git
git clone https://github.com/king-hacking/info-site.git
cd info-site
bash info.sh
```
