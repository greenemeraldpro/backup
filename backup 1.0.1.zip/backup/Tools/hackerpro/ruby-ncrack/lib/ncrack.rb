require 'ncrack/command'
require 'ncrack/version'
