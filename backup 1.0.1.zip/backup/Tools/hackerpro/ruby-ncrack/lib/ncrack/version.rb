module Ncrack
  # ruby-ncrack version
  VERSION = "0.1.0"
end
