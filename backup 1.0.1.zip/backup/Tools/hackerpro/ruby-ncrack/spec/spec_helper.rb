require 'rspec'
require 'simplecov'
SimpleCov.start

require 'ncrack/version'
include Ncrack
