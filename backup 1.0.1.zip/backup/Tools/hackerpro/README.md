[![GitHub issues](https://img.shields.io/github/issues/jaykali/hackerpro.svg)](https://github.com/technicaldada/jaykali/issues)
[![GitHub forks](https://img.shields.io/github/forks/jaykali/hackerpro.svg)](https://github.com/jaykali/hackerpro/network)
[![GitHub stars](https://img.shields.io/github/stars/jaykali/hackerpro.svg)](https://github.com/jaykali/hackerpro/stargazers)

<p align="center">***Pentesing Tools That All Hacker Needs***</p>
 <img src="logo205x250.gif" alt="hackerpro_logo" height="205" width="250"> 

## HACKERPRO Menu :

- Information Gathering
- Password Attacks
- Wireless Testing
- Exploitation Tools
- Sniffing & Spoofing
- Web Hacking
- Private Web Hacking
- Post Exploitation
- Install The HACKERPRO

### Information Gathering:

- Nmap
- Setoolkit
- Port Scanning
- Host To IP
- wordpress user
- CMS scanner
- XSStrike
- Dork - Google Dorks Passive Vulnerability Auditor
- Scan A server's Users
- Crips

### Password Attacks:

- Cupp
- Ncrack

### Wireless Testing:

- reaver
- pixiewps
- Fluxion

### Exploitation Tools:

- ATSCAN
- sqlmap
- Shellnoob
- commix
- FTP Auto Bypass
- jboss-autopwn

### Sniffing & Spoofing:

- Setoolkit
- SSLtrip
- pyPISHER
- SMTP Mailer

### Web Hacking:

- Drupal Hacking
- Inurlbr
- Wordpress & Joomla Scanner
- Gravity Form Scanner
- File Upload Checker
- Wordpress Exploit Scanner
- Wordpress Plugins Scanner
- Shell and Directory Finder
- Joomla! 1.5 - 3.4.5 remote code execution
- Vbulletin 5.X remote code execution
- BruteX - Automatically brute force all services running on a target
- Arachni - Web Application Security Scanner Framework

### Private Web Hacking:

- Get all websites
- Get joomla websites
- Get wordpress websites
- Control Panel Finder
- Zip Files Finder
- Upload File Finder
- Get server users
- SQli Scanner
- Ports Scan (range of ports)
- ports Scan (common ports)
- Get server Info
- Bypass Cloudflare

### Post Exploitation:

- Shell Checker
- POET
- Weeman

## Installation in Linux :

Open Terminal and Type : ```git clone https://github.com/jaykali/hackerpro.git```

After Downloading The File Type : ```sudo cd hackerpro && sudo python2 hackerpro.py```

Video Tutorial : Coming Soon

## Installation in Android :

1st Download [Termux](https://play.google.com/store/apps/details?id=com.termux)
</center>

Then Open Termux and Type : ```apt update && apt upgrade && apt install git && apt install python2```

After That Open Termux and Type : ```git clone https://github.com/jaykali/hackerpro.git```

Then Type : ```cd hackerpro && python2 hackerpro.py```

Video Tutorial : Coming Soon

## License :

[MIT Licence](https://github.com/jaykali/hackerpro/blob/master/LICENSE)

Thats It... If You Like This Repo. Please Share This With Your Friends..

& Don't Forget To Visit Our [Blog For Hackers](https://www.kalilinux.in) !!!

***Thankyou.***
***Keep Visiting..***
***Check our blog https://www.kalilinux.in***
***Enjoy.!!! :)***
<a href="https://www.kalilinux.in/" rel="dofollwo">Click Here</a>
