clear
sleep 1
echo '

      Select

1. hack.sh
2. fun
3. tutorial
'
read -p ">" sel1

if [ $sel1 = 1 ]; then
clear
sleep 1
read -p "
     Select
1. hack.sh
2. gather.sh
3. attack.sh

>" sel11

if [ $sel11 = 1 ]; then
bash .hack.sh

elif [ $sel11 = 2 ]; then
bash .gather.sh

elif [ $sel11 = 3 ]; then
bash .attack.sh
fi

elif [ $sel1 = 2 ]; then
clear
sleep 1
read -p "
     Select

1. howslife.sh
2. hacktarget.sh
3. hackfbi.sh
4. Banner maker
5. Cowsay
6. Fortune
7. Cowsay and Fortune

>" sel2

if [ $sel2 = 1 ]; then
bash /home/kali/fun/howslife.sh

elif [ $sel2 = 2 ]; then
bash /home/kali/fun/hacktarget.sh

elif [ $sel2 = 3 ]; then
bash /home/kali/fun/hackfbi.sh

elif [ $sel2 = 4 ]; then
clear
for (( ; ; ))
do
   read -p ">" toilet
   toilet -f big $toilet
done
fi

if [ $sel2 = 5 ]; then
clear
for (( ; ; ))
do
   read -p ">" cow
   cowsay $cow
done
fi

if [ $sel2 = 6 ]; then
clear
echo 'Click Enter'
for (( ; ; ))
do
   read -p " " $enter
   clear
   fortune$enter
done
fi

if [ $sel2 = 7 ]; then
clear
echo 'Click Enter'
for (( ; ; ))
do
   read -p "" $enter1
   clear
   fortune | cowsay
done
fi

elif [ $sel1 = 3 ];then
clear
sleep 1
echo "You can type the number on the select option"
sleep 3
bash ulti.sh
fi
